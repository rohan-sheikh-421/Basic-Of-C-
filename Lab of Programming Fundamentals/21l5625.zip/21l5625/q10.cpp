#include<iostream>
using namespace std;
int main()
{
	int a, res = 0, num1 = -1, num2 = 1;
	cin >> a;
	while (a > 0)
	{
		res = num1 + num2;
		num1 = num2;
		num2 = res;
		cout << res << endl;
		a--;
	}
	system("pause");
	return 0;
}