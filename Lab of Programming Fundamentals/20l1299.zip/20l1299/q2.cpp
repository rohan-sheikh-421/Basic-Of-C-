#include<iostream>
using namespace std;
int main()
{
	int n;
	cout<<"enter any number";
	cin>>n;
	int i=0;
	while(i<10)
	{
		
		cout<<n<<"*"<<i<<"="<<n*i<<endl;
		i++;
	}
	system("pause");
	return 0;
}