#include<iostream>
using namespace std;
int main()
{
	int n;
	cin>>n;
	 int i=0;       
	while(i<n)
	{
		cout<<i<<endl;
		i=i++;}

	system("pause");
	return 0;
}