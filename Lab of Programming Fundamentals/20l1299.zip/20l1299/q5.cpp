#include<iostream>
using namespace std;
int main()
{
	int a;
	int fac = 1;
	cin >> a;
	int i = 1;
	if (a < 0)
		cout << "invalid";
	else {
	while (i <= a)
	{
		fac = fac * i;
		i++;
	}
}
	cout << fac;
	
	system("pause");
	return 0;
}



