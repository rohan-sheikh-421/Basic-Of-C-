#include<iostream>
using namespace std;
int main()
{
	float n;
	cout << "enter a number";
	cin >> n;
	float i = 1;
	float ans=0;
	while (i <= n)
	{
		ans =ans+( 1 / i);
	i++;
}
	cout << "reciprocal" << ans;
	system("pause");
	return 0;
}