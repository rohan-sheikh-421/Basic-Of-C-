#include<iostream>
using namespace std;
int main()
{
	int length;
	int sum=0;
	int avg;
	int i=1;
	int temp;
cin>>length;
while(i<=length)
{ 
	cin>>temp;
sum=sum+temp;
i++;
}
cout<<"sum="<<sum;
avg=sum/length;
cout<<"average="<<avg;
system("pause");
return 0;
}