#include<iostream>
using namespace std;
int main()
{
   int n;
   int result=1;
   cin>>n;
   int p;
   cout<<"enter power";
   cin>>p;
   int i=1;
   while(i<=p)
   {
	   result=result*n;
	   
	   i++;
   }
	cout<<n<<"raise to power"<<p<<":"<<result;
	system("pause");
	return 0;
}