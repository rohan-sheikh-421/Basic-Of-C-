#include<iostream>
using namespace std;
int main()
{
	int n;
	int count=0;
	cin>>n;
	int arr[11]={1,2,3,4,4,5,5,5,6,6,7};
	for(int i=0;i<11;i++)
	{
		if(n==arr[i])
			count++;
			
	}
	cout<<n<<" occured "<<count<<" times";
	system("pause");
	return 0;
}