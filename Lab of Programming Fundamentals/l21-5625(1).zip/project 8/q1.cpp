#include<iostream>
using namespace std;
int main()
{
	int arr1[5]= {5,6,4,8,3};
	int max=arr1[0];
	int min=arr1[4];
	for(int i=0;i<5;i++)
	{
		cout<<arr1[i];
	}




	int arr[5];
	for(int i=0;i<5;i++)
	{
		cin>>arr[i];
	}
	for(int i=0;i<5;i++)
	{
		cout<<arr[i];
	}
	for(int i=0;i<5;i++)
	{
		if(arr[i]>max)
			max=arr[i];
			
	}cout<<"greatest="<<max;
	for(int i=0;i<5;i++)
	{
		if(arr[i]<min)
			min=arr[i];
			
	}cout<<"smallest="<<min;

	system("pause");
	return 0;
}


