#include<iostream>
using namespace std;
int main()
{
	int arr[]={2,5,6,8,7,5,3,4,2,1};
	int a2[]={7,5,3};
	for(int i=0;i<10;i++)
	{
      if(arr[i]==a2[0])
	  {
		  if(arr[i+1]==a2[1]){
			  if(arr[i+2]==a2[2]){
				  cout<<"subset exists from index"<<i<<"to index "<<i+2;
			  }
		  }
	  }
	
				
	}
	
	system("pause");
	return 0;
	}

