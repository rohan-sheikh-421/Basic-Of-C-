#include<iostream>
using namespace std;
int main()
{
	int arr[5];
	for(int i=0;i<5;i++)
	{
		cin>>arr[i];
	}
	int a,b,sum;
	cin>>a>>b;
	sum=a+b;
	for(int i=0;i<5;i++)
	{
		if(sum==arr[i])
		{cout<<"number is in the array"<<endl;	
		cout<<"index"<<i;}
	}
	
	
	system("pause");
	return 0;
}
