#include<iostream>
using namespace std;
int main()
{
	int A[7]={5,4,6,-11,-9,18,-7};

	int n=0;
	int t=0;
	for(int i=0;i<7;i++)
	{
		if(A[i]<0){
			int temp=A[n];
			A[n]=A[i];
			A[i]=temp;
			n=n+1;
		}
	}
	for(int i=0;i<7;i++)
	{
		cout<<A[i]<<" ";
	}
	system("pause");
	return 0;
}

