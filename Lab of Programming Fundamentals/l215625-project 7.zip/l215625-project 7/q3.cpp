#include <iostream>
 
void fibonacci(int n)
{
    int n1=0;
    int n2=1;
    int next=0;
    cout<<"fibonacci series is"<<n1<<", "<<n2<<", ";
    next=n1+n2;
    while(next<=n)
    {
        cout<<next<<", ";
        n1=n2;
        n2=next;
        next=n1+n2;
        
    }
}
int main() {
static int n;
cin>>n;
fibonacci(n);
cout<<n;
system("pause");

    return 0;
}