#include<iostream>
using namespace std;

void palindrome(int n)
{
int rev=0;
int rem;
int temp=n;
while(n>0)
{
    rem=n%10;
    rev=rev*10+rem;
    n/=10;
}
if(rev==temp)
cout<<"yes";
else
 cout<<"no";
}

int main()
{
    int a;
    cin>>a;
    palindrome(a);
    system("pause");
    return 0;
}